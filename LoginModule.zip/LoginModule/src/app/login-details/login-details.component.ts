import {Component, OnInit} from '@angular/core';
import {LoginModel} from "../model/loginModel";
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';
import {FormBuilder, FormGroup, Validators,AbstractControl} from '@angular/forms';
import {Observable} from "rxjs"
// @ts-ignore
@Component({
  selector: 'app-login-details',
  templateUrl: './login-details.component.html',
  styleUrls: ['./login-details.component.css']
})

export class LoginDetailsComponent implements OnInit {
  title = 'SignInModule';
  submitted = false;
  loginModel = new LoginModel("", "");
  error: any;
  // @ts-ignore
  loginform: FormGroup;
  private loginUrl = "http://localhost:8081/login-service/authorization";

  constructor(
    private http: HttpClient,
    private _router: Router,
    private formBuilder: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.error = "";
    this.loginform = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, ]]
    });
  }
  get f(): { [key: string]: AbstractControl } {
    return this.loginform.controls;
  }
  // @ts-ignore
  login():Observable<any> {
    this.submitted = true;

    if (this.loginform.invalid) {
      // @ts-ignore
      return;
    }
    const body = {username: this.loginModel.username, password: this.loginModel.psw};
    this.http.post<any>(this.loginUrl, body)
      .subscribe({
        next: data => {
          this.error = ""
          // @ts-ignore
          localStorage.setItem('currentUser', this.loginUrl, JSON.stringify(data));
          this._router.navigate(['country']);
        },
        error: error => {
          this.error = "Username or Password is Incorrect."
        }
      });
  }
  signUp() {
    this._router.navigate(['signup']);
  }
}
