import {fakeAsync, TestBed, tick} from '@angular/core/testing';
import { LoginDetailsComponent } from './login-details.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {Router} from "@angular/router";
import {RouterTestingModule} from "@angular/router/testing";
import {FormBuilder} from "@angular/forms";


describe('LoginDetailsComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        LoginDetailsComponent
      ],
      providers:[
        FormBuilder
      ]
    }).compileComponents();
  });

  it('should create the loginApp', () => {
    const fixture = TestBed.createComponent(LoginDetailsComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'SignInModule'`, () => {
    const fixture = TestBed.createComponent(LoginDetailsComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('SignInModule');
  });
});

describe('happyFlow Login flow', () => {
  let component: LoginDetailsComponent;
  let httpController :HttpTestingController;
  let url = 'http://localhost:8081/login-service/verify';
  let response ={"token":"Bearer eyJhbGciOiJIUzUxMiJ9"};
  let location: Location;
  let router: Router;
  let fixture;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    component= TestBed.inject(LoginDetailsComponent);
    httpController = TestBed.inject(HttpTestingController);
    it('should call the login service and return response', () => {
      component.login().subscribe((res: any)=>{
        expect(res).toEqual(response);
      });
      const req = httpController.expectOne({
        method: 'POST',
        url: `${url}`,
      });
      req.flush(response);
    });

    it('navigate to "" redirects you to /signup', fakeAsync(() => { (1)
      router.navigate(['signup']); (2)
      tick(); (3)
      expect(location.pathname).toBe('/signup'); (4)
    }));
  });


  });
