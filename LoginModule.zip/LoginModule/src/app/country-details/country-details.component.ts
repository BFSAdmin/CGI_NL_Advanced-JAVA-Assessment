import {Component, Injectable, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Country} from "../model/country.model";
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators,AbstractControl} from '@angular/forms';


@Injectable()
@Component({
  selector: 'app-country-details',
  templateUrl: './country-details.component.html',
  styleUrls: ['./country-details.component.css']
})
export class CountryDetailsComponent implements OnInit {
  title = 'CountryDetails';
  countryUrl = 'http://localhost:8081/login-service/country-details';  // URL to web api
  country: any;
  model = new Country("", "", "");
  enableEdit: boolean = false;
  enableAdd: boolean = false;
  submitted = false;
  error: any;
  // @ts-ignore
  countryform:FormGroup;
  constructor(
    private http: HttpClient,
    private _router: Router,
    private formBuilder: FormBuilder
    ) {
  }

  ngOnInit(): void {
    this.error = ""
    if (!this.isLoggedIn()) {
      this.loginPage();
    }
    this.getCountry();
    this.enableAdd = true;

    this.countryform = this.formBuilder.group({
      countryName: ['', Validators.required]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.countryform.controls;
  }
  // @ts-ignore
  addCountry(): Observable<any> {
    this.submitted = true;

    if (this.countryform.invalid) {
      // @ts-ignore
      return;
    }
    const body = {id: this.model.id, countryname: this.model.countryName, updatename: this.model.updateName};
    this.http.post<any>(this.countryUrl, body)
      .subscribe({
        next: data => {
          this.getCountry();
          this.model.countryName = "";
          this.error = ""
        },
        error: error => {
        }
      });
  }

  // @ts-ignore
  updateCountry(): Observable<any> {
    const body = {id: this.model.id, countryname: this.model.updateName, updatename: this.model.countryName};
    this.http.post<any>(this.countryUrl, body)
      .subscribe({
        next: data => {
          this.getCountry();
          this.model.countryName = "";
          this.error = ""
        },
        error: error => {
        }
      });

  }

  // @ts-ignore
  getCountry(): Observable<any> {
    this.error = ""
    this.http.get<any>(this.countryUrl).subscribe({
      next :data => {
      this.country = data.countryNames;
    },
    error: error => {
        this.error= "Country Details is not found";
    }
    });
  }

  editCountry(index?: number) {
    this.enableAdd = false;
    this.enableEdit = true;
    // @ts-ignore
    this.model.countryName = this.country[index].countryName;
    // @ts-ignore
    this.model.updateName = this.country[index].countryName;
    // @ts-ignore
    this.model.id = this.country[index].id;
  }

  loginPage() {
    this._router.navigate(['']);
  }


  logout() {
    localStorage.removeItem('currentUser');
    this.loginPage();
  }

  isLoggedIn() {
    if (localStorage.getItem('currentUser')) {
      return true;
    }
    return false;
  }

  getAuthorizationToken() {
    // @ts-ignore
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    return currentUser.token;
  }


}
