import {TestBed} from '@angular/core/testing';

import {CountryDetailsComponent} from './country-details.component';
import {RouterTestingModule} from "@angular/router/testing";
import {HttpClientTestingModule, HttpTestingController} from "@angular/common/http/testing";
import {HttpResponse} from "@angular/common/http";
import {Router} from "@angular/router";

describe('CountryDetailsComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        CountryDetailsComponent
      ],
    }).compileComponents();
  });

  it('should create the countryApp', () => {
    const fixture = TestBed.createComponent(CountryDetailsComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'CountryDetails'`, () => {
    const fixture = TestBed.createComponent(CountryDetailsComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('CountryDetails');
  });


   /* it('should render title', () => {
      const fixture = TestBed.createComponent(CountryDetailsComponent);
      fixture.detectChanges();
      const compiled = fixture.nativeElement;
      //expect(compiled.querySelector('.content span').textContent).toContain('LoginModule app is running!');
    });*/
});


describe('happyFlow country Details flow', () => {
  let component: CountryDetailsComponent;
  let httpController :HttpTestingController;
  let countryUrl = 'http://localhost:8081/login-service/country-details';
  let location: Location;
  let router: Router;
  let fixture;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    component= TestBed.inject(CountryDetailsComponent);
    httpController = TestBed.inject(HttpTestingController);
    it('should call the add country service and return response', () => {
      component.addCountry().subscribe((res: any)=>{
        expect(res).toEqual(true);
      });
      const req = httpController.expectOne({
        method: 'POST',
        url: `${countryUrl}`,
      });
      const expectedResponse = new HttpResponse({ status: 200, statusText: 'Created', body: true });
      req.event(expectedResponse);
      req.flush(true);
    });

    it('should turn 500 error into return of the requested add country', () => {
      component.addCountry().subscribe(
        data => expect(data).toEqual(false, 'should return the false'),
        fail
      );
      const req = httpController.expectOne(component.countryUrl);
      // respond with a 500 and the error message in the body
      const msg = '500 error';
      req.flush(msg, { status: 500, statusText: 'Internal server error' });
    });


    it('should call the update country service and return response', () => {
      component.addCountry().subscribe((res: any)=>{
        expect(res).toEqual(true);
      });
      const req = httpController.expectOne({
        method: 'POST',
        url: `${countryUrl}`,
      });
      const expectedResponse = new HttpResponse({ status: 200, statusText: 'updated', body: true });
      req.event(expectedResponse);
      req.flush(true);
    });

    it('should turn 500 error into return of the requested update country', () => {
      component.addCountry().subscribe(
        data => expect(data).toEqual(false, 'should return the false'),
        fail
      );
      const req = httpController.expectOne(component.countryUrl);
      // respond with a 500 and the error message in the body
      const msg = '500 error';
      req.flush(msg, { status: 500, statusText: 'Internal server error' });
    });

    it('should call the Get country service and return country details', () => {
      component.addCountry().subscribe((res: any)=>{
        expect(res).toEqual(true);
      });
      const req = httpController.expectOne({
        method: 'GET',
        url: `${countryUrl}`,
      });
      const expectedResponse = new HttpResponse({ status: 200, statusText: 'List of country', body: true });
      req.event(expectedResponse);
      req.flush(true);
    });

    it('should turn 500 error into return of the requested Get country', () => {
      component.addCountry().subscribe(
        data => expect(data).toEqual(false, 'should return the false'),
        fail
      );
      const req = httpController.expectOne(component.countryUrl);
      // respond with a 500 and the error message in the body
      const msg = '500 error';
      req.flush(msg, { status: 500, statusText: 'Internal server error' });
    });


  });

});
