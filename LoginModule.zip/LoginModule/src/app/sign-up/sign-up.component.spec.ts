import {ComponentFixture, fakeAsync, TestBed} from '@angular/core/testing';
import {SignUpComponent} from './sign-up.component';
import {RouterTestingModule} from '@angular/router/testing';
import {Router} from "@angular/router";
import {HttpClientTestingModule, HttpTestingController} from "@angular/common/http/testing";

describe('SignUpComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        SignUpComponent
      ],
    }).compileComponents();
  });

  it('should create the countryApp', () => {
    const fixture = TestBed.createComponent(SignUpComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'SignUpModule'`, () => {
    const fixture = TestBed.createComponent(SignUpComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('SignUpModule');
  });
});
describe('happyFlow Login flow', () => {
  let component: SignUpComponent;
  let httpController: HttpTestingController;
  let url = 'http://localhost:8081/login-service/verify';
  let router: Router;
  let fixture: ComponentFixture<SignUpComponent>;
  beforeEach(() => {
    fixture = TestBed.createComponent(SignUpComponent);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SignUpComponent]
    });
    component = TestBed.inject(SignUpComponent);
    httpController = TestBed.inject(HttpTestingController);
    it('should be created', () => {
      expect(component).toBeTruthy();
    });

    it('should call the sign-up service and return response', () => {
      component.signUp().subscribe((res: any) => {
        expect(res).toEqual(true);
      });
      const req = httpController.expectOne({
        method: 'POST',
        url: `${url}`,
      });
      req.flush(true);
    });

    it('test post method call', () => {
      component.signUp().subscribe(
        respo => {
          expect(respo).toEqual(true)
        }
      );
      const url = `${component.registrationURL}`;
      const req = httpController.expectOne(`${url}`)
      expect(req.request.method).toEqual('POST')
    });

    it('navigate to "" redirects you to /sign page when login page method called', fakeAsync(() => {
      (1)
      const component = fixture.componentInstance;
      // @ts-ignore
      const navigateSpy = spyOn(router, 'loginPage');
      component.loginPage();
      // @ts-ignore
      expect(navigateSpy).toHaveBeenCalledWith("");
    }));


  });


});
