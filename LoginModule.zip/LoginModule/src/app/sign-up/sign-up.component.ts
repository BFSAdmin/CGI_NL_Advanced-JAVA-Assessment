import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {SignUp} from "../model/singup-model";
import {HttpClient} from '@angular/common/http';
import {Observable} from "rxjs";


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  title = 'SignUpModule';
  model = new SignUp("", "", "", "", "");
  error: any;
  registrationURL = "http://localhost:8081/login-service/user-details";
  constructor(private _router: Router,
              private http: HttpClient
  ) {
  }

  ngOnInit(): void {
    this.error = "";
  }

  loginPage() {
    this._router.navigate(['']);
  }
  // @ts-ignore
  signUp(): Observable<any> {
    const body = {
      username: this.model.username,
      password: this.model.psw,
      firstname: this.model.firstname,
      lastname: this.model.lastname,
      emailid: this.model.email
    };
    this.http.post<any>(this.registrationURL, body)
      .subscribe({
        next: data => {
          this.error = ""
          alert("User has been Created successfully");
          this._router.navigate(['']);
        },
        error: error => {
          this.error = "Please provide valid details or User is already Exits"
        }
      });
  }

}
