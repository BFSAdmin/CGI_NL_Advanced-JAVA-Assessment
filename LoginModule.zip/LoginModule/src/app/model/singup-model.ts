export class SignUp {

  constructor(
    public username: string,
    public psw: string,
    public firstname: string,
    public lastname: string,
    public email: string

  ) {  }

}
