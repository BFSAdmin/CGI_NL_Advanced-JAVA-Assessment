export class Country {
  constructor(
    public id: string,
    public countryName: string,
    public updateName: string
  ) {
  }


}
