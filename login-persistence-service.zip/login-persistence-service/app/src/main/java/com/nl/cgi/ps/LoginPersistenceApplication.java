package com.nl.cgi.ps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginPersistenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginPersistenceApplication.class, args);
	}

}
