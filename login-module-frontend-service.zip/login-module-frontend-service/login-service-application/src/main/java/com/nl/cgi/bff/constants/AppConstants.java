package com.nl.cgi.bff.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class AppConstants {
    public static final String X_AUTH_USER = "X-AUTH-USER";

}
